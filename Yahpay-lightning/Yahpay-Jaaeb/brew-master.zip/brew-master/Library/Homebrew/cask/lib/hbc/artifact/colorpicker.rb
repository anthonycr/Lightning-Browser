require "hbc/artifact/moved"

module Hbc
  module Artifact
    class Colorpicker < Moved
    end
  end
end
