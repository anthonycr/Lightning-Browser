module Hbc
  class DSL
    class UninstallPostflight < Base
    end
  end
end
