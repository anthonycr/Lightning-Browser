require "hbc/artifact/moved"

module Hbc
  module Artifact
    class InputMethod < Moved
    end
  end
end
