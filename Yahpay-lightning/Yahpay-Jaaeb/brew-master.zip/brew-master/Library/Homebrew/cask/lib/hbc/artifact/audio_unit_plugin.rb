require "hbc/artifact/moved"

module Hbc
  module Artifact
    class AudioUnitPlugin < Moved
    end
  end
end
