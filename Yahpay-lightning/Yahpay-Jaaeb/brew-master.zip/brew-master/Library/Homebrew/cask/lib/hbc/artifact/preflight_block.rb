require "hbc/artifact/abstract_flight_block"

module Hbc
  module Artifact
    class PreflightBlock < AbstractFlightBlock
    end
  end
end
