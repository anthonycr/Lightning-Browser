require "hbc/artifact/moved"

module Hbc
  module Artifact
    class ScreenSaver < Moved
    end
  end
end
