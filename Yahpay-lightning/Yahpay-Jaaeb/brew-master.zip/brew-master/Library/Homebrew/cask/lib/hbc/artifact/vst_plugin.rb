require "hbc/artifact/moved"

module Hbc
  module Artifact
    class VstPlugin < Moved
    end
  end
end
