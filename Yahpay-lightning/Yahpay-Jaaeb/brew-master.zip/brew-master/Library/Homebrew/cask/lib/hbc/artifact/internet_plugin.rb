require "hbc/artifact/moved"

module Hbc
  module Artifact
    class InternetPlugin < Moved
    end
  end
end
