require "formula_cellar_checks"
require "extend/os/mac/formula_cellar_checks" if OS.mac?
