require "extend/ENV/shared"
require "extend/os/mac/extend/ENV/shared" if OS.mac?
