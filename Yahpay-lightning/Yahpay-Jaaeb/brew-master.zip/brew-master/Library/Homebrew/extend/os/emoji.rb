require "os"
require "emoji"
require "extend/os/mac/emoji" if OS.mac?
