require "keg_relocate"
require "extend/os/mac/keg_relocate" if OS.mac?
