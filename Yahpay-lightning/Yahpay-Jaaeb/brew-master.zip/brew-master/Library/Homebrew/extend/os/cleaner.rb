require "cleaner"
require "extend/os/mac/cleaner" if OS.mac?
